# coding=utf-8

MAX_FIELD_LENGTH = 128