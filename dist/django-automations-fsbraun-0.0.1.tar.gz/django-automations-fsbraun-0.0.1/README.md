# Django-automations

A lightweight framework to collect all processes of your django app in one place.

Use cases:

* Marketing automations, customer journeys
* Simple business processes which require user interactions
* Running regular tasks

## Roadmap
* End of June 2021, core functionality
* August 2021, first release

## Feedback
This project is in a very early stage. All feedback is welcome! Please mail me at fsbraun(at)gmx.de

# Example

