# coding=utf-8

# Create your views here.
from django.views import View


class TaskView(View):
    pass

class TaskListView(View):
    pass

class TaskDashboard(View):
    pass
